package com.me.ws;

import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class ArmsClient {

	public static void main(String[] args) throws Exception{
		URL url = new URL("http://127.0.0.1:8000/myself?wsdl");
		QName qname = new QName("http://ws.me.com/","ArmstrongNumberService");
		Service service = Service.create(url, qname);
		ArmstrongNumberService endPoint = service.getPort(ArmstrongNumberService.class);
		Scanner in = new Scanner(System.in);
		
		int n = 0 ;
		boolean result;
		System.out.print("Enter first number: ");
		n = Integer.parseInt(in.nextLine());
		result=endPoint.isArms(n);
		if(result==true){
			System.out.println("Number is armstrong");
		}
		else{
			System.out.println("Number is not armstrong");
		}
		
		in.close();
	}
}